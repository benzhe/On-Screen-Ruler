Website:http://on-screen-ruler.blogspot.com

Introduce:

On Screen Ruler is a powerful and easy-to-use ruler work in PC. The ruler lets you easily measures objects in your screen or out of screen. This is especially useful when measuring graphics, web page browser sizes or whatever.It can display Pixels, Inches or Centimeters. It needs .net framework 2.0, if it comes error in running, please download framework from Microsoft.


How To Use:

Almost all of the features are set in the Right Click Menu. Here are some details.

01. You can drag and move the ruler;

02. The little image in the lower right corner is used to resize the ruler, and the label next is the size of the ruler ;

03. Use Mouse Scroll to change the transparency;

04. If you want to set the ruler topmost, just tick "Stay On Top";

05. Left Click to mark;

06. Hide or show mark using "Enable Vertical Mark" or "Enable Horizontal Mark";

07. Hide of show tickers using "Top Ticker" or "Left Ticker";

08. You can customize the color by using "Change Ruler Color" ,  "Change Mark Color" and "Change Background Color";

09. You can change the unit to "Pixel", "Centimeter" or "Inche", just tick what you want;

10. For using "Centimeter" and "Inche" as unit, you must make correction for the ruler, see Advanced Using below;

11. After version v1.04, you can move the mark by using arrow keys in keyboard. and Enter or Space can be used to mark.


Advanced Using:

1.Measure objects out of screen:

As you can see, you can measure things of centimeter and inche by this ruler. All you need is a bank card (or another card with credit card size) to correct the ticker. You can find more information inside "Correction For Out-Screen" in Right Click Menu.


2.Measure objects in documents:

Sometimes you want to know the size of objects in document before they printed out. This ruler can also be used for this. What you need is open or create a new A4 page document, then choose "Correction For In-Screen" to fixed the panel to your page.

3. Both setting above will be saved after first correction��so just click OK to pass when using again.

4. The Chinese "�޸�����" in Right Click Menu means change the language to Chinese, maybe you do not need this feature :-)


That's all I think you need to know about this on screen ruler. If you are confused by some feature, just feel free to send me feedback. My email is ben304zhe@gmail.com. And you can just leave a comment below.

In the end, as you can see, this tool is totally free, and i am just a college student in china and receive nothing for making this tool. So if you like this tool, please support me by making a small donation. Thanks :D